const banner = `THANKS TO AIRDROP HUNTER TOC - Tool Shared By FORESTARMY https://t.me/forestarmy`;
export default banner;
